import FsAddbranch from "../Components/FsAddbranch";
import Header from "../Components/Header";
import HeaderThree from "../Components/HeaderThree";
// import HeaderTwo from "../Components/HeaderTwo";





const Addbranch = () =>{
return(
    <>
    <Header></Header>
    <HeaderThree tittle="ADD BRANCH FORM " />
    <FsAddbranch/>
   
    </>
)
}

export default Addbranch;